import { X, Book } from 'lucide-react';

interface BookDetailsModalProps {
  book: any;
  onClose: () => void;
  onAddToLibrary?: (book: any) => void;
  showAddButton?: boolean;
}

export function BookDetailsModal({ book, onClose, onAddToLibrary, showAddButton = false }: BookDetailsModalProps) {
  return (
    <div className="fixed inset-0 bg-black/60 z-[100] flex items-end" onClick={onClose}>
      <div
        className="bg-background-light rounded-t-3xl w-full max-w-lg mx-auto max-h-[85vh] overflow-y-auto animate-slide-up"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-background-light/95 backdrop-blur-sm z-10 px-6 pt-4 pb-3 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold text-text-main-light">Détails du livre</h2>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors"
              aria-label="Fermer"
            >
              <X className="w-5 h-5 text-text-sub-light" />
            </button>
          </div>
        </div>

        <div className="px-6 py-6">
          <div className="flex gap-4 mb-6">
            <div className="w-28 shrink-0 aspect-[2/3] rounded-xl overflow-hidden bg-gray-200 shadow-lg">
              {book.cover_url ? (
                <img
                  src={book.cover_url}
                  alt={book.title}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                    (e.target as HTMLImageElement).parentElement!.innerHTML = `
                      <div class="w-full h-full flex items-center justify-center">
                        <svg class="w-12 h-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                        </svg>
                      </div>
                    `;
                  }}
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center">
                  <Book className="w-12 h-12 text-text-sub-light" />
                </div>
              )}
            </div>

            <div className="flex-1">
              <h3 className="text-2xl font-bold text-text-main-light mb-2 leading-tight">
                {book.title}
              </h3>
              <p className="text-lg text-text-sub-light font-medium mb-3">
                {book.author}
              </p>

              <div className="flex flex-wrap gap-2">
                {book.genre && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                    {book.genre}
                  </span>
                )}
                {book.total_pages > 0 && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-gray-100 text-gray-700">
                    {book.total_pages} pages
                  </span>
                )}
                {book.edition && book.edition !== 'Standard Edition' && (
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-green-50 text-green-700 border border-green-200">
                    {book.edition}
                  </span>
                )}
              </div>
            </div>
          </div>

          {(book.publisher || book.isbn) && (
            <div className="mb-6 px-4 py-3 bg-gray-50 rounded-xl">
              <div className="space-y-1">
                {book.publisher && (
                  <div className="flex items-start gap-2">
                    <span className="text-xs font-semibold text-text-sub-light min-w-[70px]">Éditeur:</span>
                    <span className="text-xs text-text-main-light font-medium">{book.publisher}</span>
                  </div>
                )}
                {book.isbn && (
                  <div className="flex items-start gap-2">
                    <span className="text-xs font-semibold text-text-sub-light min-w-[70px]">ISBN:</span>
                    <span className="text-xs text-text-main-light font-medium">{book.isbn}</span>
                  </div>
                )}
              </div>
            </div>
          )}

          {book.description && (
            <div className="mb-6">
              <h4 className="text-sm font-bold text-text-main-light mb-3 uppercase tracking-wide">
                Résumé
              </h4>
              <p className="text-text-main-light leading-relaxed text-base">
                {book.description}
              </p>
            </div>
          )}

          {showAddButton && onAddToLibrary && (
            <button
              onClick={() => onAddToLibrary(book)}
              className="w-full bg-primary text-black py-4 rounded-xl font-bold hover:brightness-95 transition-all shadow-sm"
            >
              Ajouter à ma bibliothèque
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
