import { useEffect, useState } from 'react';
import { X, Book, Plus, Edit3 } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { ManageBookModal } from './ManageBookModal';
import { AddBookStatusModal } from './AddBookStatusModal';

interface BookDetailsWithManagementProps {
  bookId: string;
  onClose: () => void;
}

export function BookDetailsWithManagement({ bookId, onClose }: BookDetailsWithManagementProps) {
  const { user } = useAuth();
  const [book, setBook] = useState<any>(null);
  const [userBook, setUserBook] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [showManageModal, setShowManageModal] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);

  useEffect(() => {
    loadBookDetails();
  }, [bookId]);

  const loadBookDetails = async () => {
    const { data: bookData } = await supabase
      .from('books')
      .select('*')
      .eq('id', bookId)
      .single();

    if (bookData) {
      setBook(bookData);
    }

    if (user) {
      const { data: userBookData } = await supabase
        .from('user_books')
        .select('*')
        .eq('user_id', user.id)
        .eq('book_id', bookId)
        .maybeSingle();

      if (userBookData) {
        setUserBook(userBookData);
      }
    }

    setLoading(false);
  };

  const handleAddToLibrary = () => {
    setShowAddModal(true);
  };

  const handleStatusChange = async (status: 'reading' | 'completed' | 'want_to_read') => {
    if (!user || !userBook) return;

    await supabase
      .from('user_books')
      .update({ status })
      .eq('id', userBook.id);

    setShowManageModal(false);
    loadBookDetails();
  };

  const handleDelete = async () => {
    if (!user || !userBook) return;

    await supabase
      .from('user_books')
      .delete()
      .eq('id', userBook.id);

    setShowManageModal(false);
    onClose();
  };

  const handleAddComplete = async (status: 'reading' | 'completed' | 'want_to_read') => {
    if (!user || !book) return;

    try {
      const { data: existingUserBook } = await supabase
        .from('user_books')
        .select('id')
        .eq('user_id', user.id)
        .eq('book_id', book.id)
        .maybeSingle();

      if (existingUserBook) {
        setShowAddModal(false);
        onClose();
        return;
      }

      await supabase.from('user_books').insert({
        user_id: user.id,
        book_id: book.id,
        status: status,
        current_page: 0,
      });

      setShowAddModal(false);
      onClose();
    } catch (error) {
      console.error('Error adding book:', error);
    }
  };

  if (loading || !book) {
    return (
      <div className="fixed inset-0 bg-black/60 z-[100] flex items-center justify-center">
        <div className="bg-background-light rounded-2xl p-8">
          <div className="text-text-sub-light">Chargement...</div>
        </div>
      </div>
    );
  }

  return (
    <>
      <div
        className={`fixed inset-0 bg-black/60 z-[100] flex items-end ${showAddModal ? 'hidden' : ''}`}
        onClick={onClose}
      >
        <div
          className="bg-background-light rounded-t-3xl w-full max-w-lg mx-auto max-h-[85vh] overflow-y-auto animate-slide-up"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="sticky top-0 bg-background-light/95 backdrop-blur-sm z-10 px-6 pt-4 pb-3 border-b border-gray-200">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-bold text-text-main-light">Détails du livre</h2>
              <button
                onClick={onClose}
                className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-gray-100 transition-colors"
                aria-label="Fermer"
              >
                <X className="w-5 h-5 text-text-sub-light" />
              </button>
            </div>
          </div>

          <div className="px-6 py-6">
            <div className="flex gap-4 mb-6">
              <div className="w-28 shrink-0 aspect-[2/3] rounded-xl overflow-hidden bg-gray-200 shadow-lg">
                {book.cover_url ? (
                  <img
                    src={book.cover_url}
                    alt={book.title}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center">
                    <Book className="w-12 h-12 text-text-sub-light" />
                  </div>
                )}
              </div>

              <div className="flex-1">
                <h3 className="text-2xl font-bold text-text-main-light mb-2 leading-tight">
                  {book.title}
                </h3>
                <p className="text-lg text-text-sub-light font-medium mb-3">
                  {book.author}
                </p>

                <div className="flex flex-wrap gap-2">
                  {book.genre && (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-blue-50 text-blue-700 border border-blue-200">
                      {book.genre}
                    </span>
                  )}
                  {book.total_pages > 0 && (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-gray-100 text-gray-700">
                      {book.total_pages} pages
                    </span>
                  )}
                  {book.edition && book.edition !== 'Standard Edition' && (
                    <span className="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold bg-green-50 text-green-700 border border-green-200">
                      {book.edition}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {(book.publisher || book.isbn) && (
              <div className="mb-6 px-4 py-3 bg-gray-50 rounded-xl">
                <div className="space-y-1">
                  {book.publisher && (
                    <div className="flex items-start gap-2">
                      <span className="text-xs font-semibold text-text-sub-light min-w-[70px]">Éditeur:</span>
                      <span className="text-xs text-text-main-light font-medium">{book.publisher}</span>
                    </div>
                  )}
                  {book.isbn && (
                    <div className="flex items-start gap-2">
                      <span className="text-xs font-semibold text-text-sub-light min-w-[70px]">ISBN:</span>
                      <span className="text-xs text-text-main-light font-medium">{book.isbn}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {book.description && (
              <div className="mb-6">
                <h4 className="text-sm font-bold text-text-main-light mb-3 uppercase tracking-wide">
                  Résumé
                </h4>
                <p className="text-text-main-light leading-relaxed text-base">
                  {book.description}
                </p>
              </div>
            )}

            {userBook ? (
              <button
                onClick={() => setShowManageModal(true)}
                className="w-full bg-stone-900 text-white py-4 rounded-xl font-bold hover:bg-stone-800 transition-all shadow-sm flex items-center justify-center gap-2"
              >
                <Edit3 className="w-5 h-5" />
                Gérer ce livre
              </button>
            ) : (
              <button
                onClick={handleAddToLibrary}
                className="w-full bg-primary text-black py-4 rounded-xl font-bold hover:brightness-95 transition-all shadow-sm flex items-center justify-center gap-2"
              >
                <Plus className="w-5 h-5" />
                Ajouter à ma bibliothèque
              </button>
            )}
          </div>
        </div>
      </div>

      {showManageModal && userBook && (
        <ManageBookModal
          bookTitle={book.title}
          currentStatus={userBook.status}
          onClose={() => setShowManageModal(false)}
          onChangeStatus={handleStatusChange}
          onDelete={handleDelete}
        />
      )}

      {showAddModal && book && (
        <AddBookStatusModal
          bookTitle={book.title}
          onClose={() => setShowAddModal(false)}
          onSelect={handleAddComplete}
        />
      )}
    </>
  );
}
