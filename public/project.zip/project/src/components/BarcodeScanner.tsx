import { useEffect, useRef, useState } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { X, Camera } from 'lucide-react';

interface BarcodeScannerProps {
  onScan: (isbn: string) => void;
  onClose: () => void;
}

export function BarcodeScanner({ onScan, onClose }: BarcodeScannerProps) {
  const scannerRef = useRef<Html5Qrcode | null>(null);
  const [error, setError] = useState<string>('');
  const [scanning, setScanning] = useState(false);
  const hasScannedRef = useRef(false);

  useEffect(() => {
    startScanner();

    return () => {
      stopScanner();
    };
  }, []);

  const startScanner = async () => {
    try {
      setScanning(true);
      setError('');

      const scanner = new Html5Qrcode('barcode-reader');
      scannerRef.current = scanner;

      await scanner.start(
        { facingMode: 'environment' },
        {
          fps: 10,
          qrbox: { width: 250, height: 150 },
          formatsToSupport: [
            0,
            1,
            2,
            3,
            4,
            5,
            6,
            7,
            8
          ]
        },
        (decodedText) => {
          if (!hasScannedRef.current) {
            hasScannedRef.current = true;
            stopScanner();
            onScan(decodedText);
          }
        },
        (errorMessage) => {
          console.log(errorMessage);
        }
      );
    } catch (err) {
      console.error('Error starting scanner:', err);
      setError('Impossible d\'accéder à la caméra. Veuillez vérifier les autorisations.');
      setScanning(false);
    }
  };

  const stopScanner = async () => {
    if (scannerRef.current) {
      try {
        await scannerRef.current.stop();
        scannerRef.current.clear();
      } catch (err) {
        console.error('Error stopping scanner:', err);
      }
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/90 z-50 flex flex-col"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          stopScanner();
          onClose();
        }
      }}
    >
      <div className="flex items-center justify-between p-4 bg-black/50">
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <Camera className="w-6 h-6" />
          Scanner le code-barres
        </h2>
        <button
          onClick={() => {
            stopScanner();
            onClose();
          }}
          className="text-white hover:text-gray-300 transition-colors"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center p-4">
        <div id="barcode-reader" className="w-full max-w-md rounded-lg overflow-hidden"></div>

        {error && (
          <div className="mt-4 p-4 bg-red-500/20 border border-red-500 rounded-lg text-white text-center max-w-md">
            {error}
          </div>
        )}

        {scanning && !error && (
          <div className="mt-4 text-white text-center">
            <p className="text-lg font-semibold mb-2">Placez le code-barres dans le cadre</p>
            <p className="text-sm text-gray-300">Le livre sera ajouté automatiquement</p>
          </div>
        )}
      </div>
    </div>
  );
}
