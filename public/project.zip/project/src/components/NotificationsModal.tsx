import { useEffect, useState } from 'react';
import { X, BookOpen, Users, Heart } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { formatDistanceToNow } from '../utils/dateUtils';

interface NotificationsModalProps {
  onClose: () => void;
}

interface Notification {
  id: string;
  type: 'activity' | 'follow' | 'reaction';
  user: {
    display_name: string;
    username: string;
    avatar_url?: string;
  };
  activity?: {
    title: string;
    pages_read?: number;
  };
  created_at: string;
}

export function NotificationsModal({ onClose }: NotificationsModalProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();

  useEffect(() => {
    loadNotifications();
  }, [user]);

  const loadNotifications = async () => {
    if (!user) return;

    const { data: follows } = await supabase
      .from('follows')
      .select('following_id')
      .eq('follower_id', user.id);

    if (!follows || follows.length === 0) {
      setLoading(false);
      return;
    }

    const followingIds = follows.map((f) => f.following_id);

    const { data: activities } = await supabase
      .from('activities')
      .select('id, title, pages_read, created_at, user_id, user_profiles!activities_user_id_fkey(display_name, username, avatar_url)')
      .in('user_id', followingIds)
      .order('created_at', { ascending: false })
      .limit(20);

    if (activities) {
      const notifs: Notification[] = activities.map((activity: any) => ({
        id: activity.id,
        type: 'activity',
        user: {
          display_name: activity.user_profiles.display_name,
          username: activity.user_profiles.username,
          avatar_url: activity.user_profiles.avatar_url,
        },
        activity: {
          title: activity.title,
          pages_read: activity.pages_read,
        },
        created_at: activity.created_at,
      }));
      setNotifications(notifs);
    }

    setLoading(false);
  };

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'activity':
        return BookOpen;
      case 'follow':
        return Users;
      case 'reaction':
        return Heart;
      default:
        return BookOpen;
    }
  };

  const getNotificationText = (notif: Notification) => {
    if (notif.type === 'activity' && notif.activity) {
      return (
        <>
          <span className="font-semibold">{notif.user.display_name}</span> a lu
          {notif.activity.pages_read && notif.activity.pages_read > 0 && (
            <span className="font-semibold"> {notif.activity.pages_read} pages</span>
          )}
        </>
      );
    }
    return <span className="font-semibold">{notif.user.display_name}</span>;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center z-50" onClick={onClose}>
      <div
        className="bg-white rounded-t-3xl max-w-2xl w-full max-h-[85vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex-shrink-0 bg-white border-b border-stone-200 px-6 py-4 flex items-center justify-between rounded-t-3xl">
          <h2 className="text-xl font-bold">Notifications</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-stone-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4">
          {loading ? (
            <div className="text-center py-12 text-text-sub-light">Chargement...</div>
          ) : notifications.length === 0 ? (
            <div className="text-center py-12">
              <BookOpen className="w-16 h-16 mx-auto mb-4 text-text-sub-light" />
              <p className="text-lg font-medium text-text-main-light mb-2">Aucune notification</p>
              <p className="text-sm text-text-sub-light">
                Suivez des utilisateurs pour voir leurs activités ici
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {notifications.map((notif) => {
                const Icon = getNotificationIcon(notif.type);
                return (
                  <div
                    key={notif.id}
                    className="flex items-start gap-3 p-4 rounded-xl hover:bg-stone-50 transition-colors"
                  >
                    <div className="w-10 h-10 bg-stone-200 rounded-full flex items-center justify-center flex-shrink-0 overflow-hidden">
                      {notif.user.avatar_url ? (
                        <img
                          src={notif.user.avatar_url}
                          alt={notif.user.display_name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <span className="text-stone-600 font-medium">
                          {notif.user.display_name.charAt(0).toUpperCase()}
                        </span>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start gap-2 mb-1">
                        <Icon className="w-4 h-4 text-primary mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-stone-900 flex-1">{getNotificationText(notif)}</p>
                      </div>
                      <p className="text-xs text-stone-500">{formatDistanceToNow(notif.created_at)}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
