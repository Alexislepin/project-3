import { Trash2, ArrowRight, X } from 'lucide-react';

interface ManageBookModalProps {
  onClose: () => void;
  onDelete: () => void;
  onChangeStatus: (status: 'reading' | 'completed' | 'want_to_read') => void;
  bookTitle: string;
  currentStatus: 'reading' | 'completed' | 'want_to_read';
}

export function ManageBookModal({
  onClose,
  onDelete,
  onChangeStatus,
  bookTitle,
  currentStatus
}: ManageBookModalProps) {
  const statusLabels = {
    reading: 'En cours',
    completed: 'Terminé',
    want_to_read: 'À lire'
  };

  const otherStatuses = (['reading', 'completed', 'want_to_read'] as const).filter(
    s => s !== currentStatus
  );

  const getStatusLabel = (status: typeof currentStatus) => {
    const labels = {
      reading: 'En cours de lecture',
      completed: 'Déjà lu',
      want_to_read: 'À lire'
    };
    return labels[status];
  };

  const getStatusColor = (status: typeof currentStatus) => {
    const colors = {
      reading: 'blue',
      completed: 'green',
      want_to_read: 'gray'
    };
    return colors[status];
  };

  return (
    <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl max-w-md w-full shadow-xl">
        <div className="p-6">
          <div className="flex items-start justify-between mb-6">
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900 mb-1">
                Gérer le livre
              </h3>
              <p className="text-sm text-gray-600">
                {bookTitle}
              </p>
              <span className={`inline-block mt-2 px-3 py-1 rounded-full text-xs font-medium bg-${getStatusColor(currentStatus)}-100 text-${getStatusColor(currentStatus)}-700`}>
                {statusLabels[currentStatus]}
              </span>
            </div>
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="space-y-3">
            <div className="text-sm font-medium text-gray-700 mb-2">
              Déplacer vers :
            </div>

            {otherStatuses.map((status) => {
              const color = getStatusColor(status);
              return (
                <button
                  key={status}
                  onClick={() => onChangeStatus(status)}
                  className={`w-full p-4 bg-${color}-50 hover:bg-${color}-100 text-left rounded-xl transition-colors flex items-center justify-between`}
                >
                  <div>
                    <div className={`font-semibold text-${color}-900`}>
                      {getStatusLabel(status)}
                    </div>
                  </div>
                  <ArrowRight className={`w-5 h-5 text-${color}-600`} />
                </button>
              );
            })}

            <button
              onClick={onDelete}
              className="w-full p-4 bg-red-50 hover:bg-red-100 text-left rounded-xl transition-colors flex items-center justify-between mt-6"
            >
              <div>
                <div className="font-semibold text-red-900">Supprimer</div>
                <div className="text-sm text-red-700">Retirer de ma bibliothèque</div>
              </div>
              <Trash2 className="w-5 h-5 text-red-600" />
            </button>
          </div>

          <button
            onClick={onClose}
            className="w-full mt-4 py-3 text-gray-600 hover:text-gray-900 font-medium transition-colors"
          >
            Annuler
          </button>
        </div>
      </div>
    </div>
  );
}
