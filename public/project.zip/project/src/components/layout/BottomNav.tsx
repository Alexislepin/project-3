import { Home, Search, BookOpen, User, Circle, TrendingUp } from 'lucide-react';

interface BottomNavProps {
  currentView: 'home' | 'search' | 'library' | 'profile' | 'insights';
  onNavigate: (view: 'home' | 'search' | 'library' | 'profile' | 'insights') => void;
  onStartSession: () => void;
}

export function BottomNav({ currentView, onNavigate, onStartSession }: BottomNavProps) {
  const navItems = [
    { id: 'home' as const, icon: Home, label: 'Accueil' },
    { id: 'insights' as const, icon: TrendingUp, label: 'Stats' },
    { id: 'record' as const, icon: Circle, label: 'Session', isCenter: true },
    { id: 'library' as const, icon: BookOpen, label: 'Bibliothèque' },
    { id: 'profile' as const, icon: User, label: 'Profil' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-card-light border-t border-gray-200 z-50 pb-safe">
      <div className="max-w-lg mx-auto flex justify-around items-center h-16 relative">
        {navItems.map((item) => {
          if (item.isCenter) {
            return (
              <div key={item.id} className="flex-1 flex justify-center">
                <button
                  onClick={onStartSession}
                  className="absolute -top-6 w-16 h-16 bg-primary rounded-full shadow-[0_4px_20px_rgba(249,245,6,0.4)] flex items-center justify-center hover:shadow-[0_6px_24px_rgba(249,245,6,0.5)] hover:scale-105 active:scale-95 transition-all border-4 border-background-light"
                  aria-label="Démarrer une session de lecture"
                >
                  <Circle className="w-8 h-8 text-black fill-current" />
                </button>
              </div>
            );
          }

          const Icon = item.icon;
          const isActive = currentView === item.id;

          return (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
                isActive ? 'text-primary' : 'text-text-sub-light'
              }`}
            >
              <Icon
                className="w-6 h-6 mb-0.5"
                strokeWidth={isActive ? 2.5 : 2}
                fill={isActive ? 'currentColor' : 'none'}
              />
              <span className={`text-[10px] ${isActive ? 'font-bold' : 'font-medium'}`}>
                {item.label}
              </span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
