import { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';
import { Check, Users, Bell, BellOff } from 'lucide-react';

const READING_GOALS = [
  { id: 'daily_15min', label: '15 minutes par jour', description: 'Commencez par une petite habitude quotidienne', target: 15, period: 'daily' },
  { id: 'daily_30min', label: '30 minutes par jour', description: 'Construisez une pratique de lecture régulière', target: 30, period: 'daily' },
  { id: 'daily_60min', label: '1 heure par jour', description: 'Consacrez du temps sérieux à la lecture', target: 60, period: 'daily' },
  { id: 'weekly_pages', label: '200 pages par semaine', description: 'Terminez des livres régulièrement', target: 200, period: 'weekly' },
];

interface OnboardingProps {
  onComplete: () => void;
}

export function Onboarding({ onComplete }: OnboardingProps) {
  const [step, setStep] = useState(1);
  const [selectedGoal, setSelectedGoal] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);
  const [notificationPermission, setNotificationPermission] = useState<NotificationPermission>('default');
  const { user } = useAuth();

  const handleRequestNotifications = async () => {
    if (!('Notification' in window)) {
      setStep(3);
      return;
    }

    try {
      const permission = await Notification.requestPermission();
      setNotificationPermission(permission);

      if (permission === 'granted') {
        setNotificationsEnabled(true);

        if (user) {
          await supabase
            .from('user_profiles')
            .update({
              notifications_enabled: true,
              goal_reminder_enabled: true,
              notification_time: '20:00:00',
            })
            .eq('id', user.id);
        }

        new Notification('Notifications activées !', {
          body: 'Vous recevrez des rappels pour vos objectifs de lecture',
          icon: '/image.png',
        });
      }
    } catch (error) {
      console.error('Error requesting notification permission:', error);
    }

    setStep(3);
  };

  const handleSkipNotifications = () => {
    setStep(3);
  };

  const handleComplete = async () => {
    if (!user) return;

    setLoading(true);

    await supabase
      .from('user_profiles')
      .update({
        interests: ['reading']
      })
      .eq('id', user.id);

    if (selectedGoal) {
      const goal = READING_GOALS.find((g) => g.id === selectedGoal);
      if (goal) {
        await supabase.from('user_goals').insert({
          user_id: user.id,
          type: selectedGoal,
          target_value: goal.target,
          current_value: 0,
          period: goal.period,
          active: true,
        });
      }
    }

    setLoading(false);
    onComplete();
  };

  return (
    <div className="min-h-screen bg-stone-50 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold tracking-tight mb-2">Lexu</h1>
          <p className="text-stone-600">Bienvenue dans votre parcours de lecture</p>
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-stone-200 p-8">
          {step === 1 && (
            <>
              <div className="mb-6">
                <h2 className="text-2xl font-semibold mb-2">Définissez votre objectif de lecture</h2>
                <p className="text-stone-600">Combien de temps voulez-vous consacrer à la lecture ?</p>
              </div>

              <div className="space-y-3 mb-8">
                {READING_GOALS.map((goal) => (
                  <button
                    key={goal.id}
                    onClick={() => setSelectedGoal(goal.id)}
                    className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                      selectedGoal === goal.id
                        ? 'border-primary bg-primary/5'
                        : 'border-stone-200 hover:border-stone-300'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="font-medium mb-1">{goal.label}</div>
                        <div className="text-sm text-stone-600">{goal.description}</div>
                      </div>
                      {selectedGoal === goal.id && (
                        <Check className="w-5 h-5 text-primary flex-shrink-0 mt-1" />
                      )}
                    </div>
                  </button>
                ))}
              </div>

              <button
                onClick={() => setStep(2)}
                disabled={!selectedGoal}
                className="w-full bg-stone-900 text-white py-3 rounded-lg font-medium hover:bg-stone-800 transition-colors disabled:opacity-50"
              >
                Continuer
              </button>
            </>
          )}

          {step === 2 && (
            <>
              <div className="mb-8 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Bell className="w-8 h-8 text-primary" />
                </div>
                <h2 className="text-2xl font-semibold mb-2">Restez motivé avec des rappels</h2>
                <p className="text-stone-600 mb-4">
                  Recevez des notifications quotidiennes pour vous rappeler de compléter vos objectifs de lecture
                </p>
                <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-left">
                  <p className="text-sm text-blue-800 mb-2 font-medium">
                    Les notifications vous aident à :
                  </p>
                  <ul className="text-xs text-blue-700 space-y-1.5">
                    <li>• Maintenir votre série de lecture quotidienne</li>
                    <li>• Atteindre vos objectifs plus facilement</li>
                    <li>• Rester motivé chaque jour</li>
                  </ul>
                </div>
              </div>

              <div className="flex flex-col gap-3">
                <button
                  onClick={handleRequestNotifications}
                  className="w-full bg-primary text-black py-3 rounded-lg font-medium hover:brightness-95 transition-all flex items-center justify-center gap-2"
                >
                  <Bell className="w-5 h-5" />
                  Activer les notifications
                </button>
                <button
                  onClick={handleSkipNotifications}
                  className="w-full border-2 border-stone-300 text-stone-700 py-3 rounded-lg font-medium hover:bg-stone-50 transition-colors"
                >
                  Peut-être plus tard
                </button>
                <button
                  onClick={() => setStep(1)}
                  className="text-sm text-stone-500 hover:text-stone-700 transition-colors mt-2"
                >
                  Retour
                </button>
              </div>
            </>
          )}

          {step === 3 && (
            <>
              <div className="mb-8 text-center">
                <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-8 h-8 text-primary" />
                </div>
                <h2 className="text-2xl font-semibold mb-2">Trouvez votre communauté de lecture</h2>
                <p className="text-stone-600">
                  Connectez-vous avec d'autres lecteurs, partagez vos progrès et découvrez de nouveaux livres ensemble sur Lexu
                </p>
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => setStep(2)}
                  className="flex-1 border-2 border-stone-300 text-stone-700 py-3 rounded-lg font-medium hover:bg-stone-50 transition-colors"
                >
                  Retour
                </button>
                <button
                  onClick={handleComplete}
                  disabled={loading}
                  className="flex-1 bg-stone-900 text-white py-3 rounded-lg font-medium hover:bg-stone-800 transition-colors disabled:opacity-50"
                >
                  {loading ? 'Configuration...' : 'Commencer'}
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
