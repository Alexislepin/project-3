import { useState, useEffect } from 'react';
import { useAuth } from './contexts/AuthContext';
import { supabase } from './lib/supabase';
import { Login } from './components/auth/Login';
import { Signup } from './components/auth/Signup';
import { Onboarding } from './components/auth/Onboarding';
import { AppLayout } from './components/layout/AppLayout';
import { Home } from './pages/Home';
import { Profile } from './pages/Profile';
import { Library } from './pages/Library';
import { Insights } from './pages/Insights';
import { ActiveSession } from './pages/ActiveSession';
import { Search } from './pages/Search';

type AuthView = 'login' | 'signup';
type AppView = 'home' | 'profile' | 'library' | 'insights' | 'search';

function App() {
  const { user, loading } = useAuth();
  const [authView, setAuthView] = useState<AuthView>('login');
  const [needsOnboarding, setNeedsOnboarding] = useState(false);
  const [currentView, setCurrentView] = useState<AppView>('home');
  const [showActiveSession, setShowActiveSession] = useState(false);
  const [checkingOnboarding, setCheckingOnboarding] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    if (user) {
      checkOnboardingStatus();
    } else {
      setCheckingOnboarding(false);
    }
  }, [user]);

  const checkOnboardingStatus = async () => {
    if (!user) return;

    const { data: profile } = await supabase
      .from('user_profiles')
      .select('interests')
      .eq('id', user.id)
      .maybeSingle();

    if (profile && profile.interests && profile.interests.length > 0) {
      setNeedsOnboarding(false);
    } else {
      setNeedsOnboarding(true);
    }

    setCheckingOnboarding(false);
  };

  const handleOnboardingComplete = () => {
    setNeedsOnboarding(false);
  };

  const handleSessionFinish = () => {
    setShowActiveSession(false);
    setRefreshKey(prev => prev + 1);
  };

  const handleNavigate = (view: AppView) => {
    setCurrentView(view);
    setRefreshKey(prev => prev + 1);
  };

  if (loading || checkingOnboarding) {
    return (
      <div className="min-h-screen bg-background-light flex items-center justify-center">
        <div className="text-text-sub-light">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return authView === 'login' ? (
      <Login onSwitchToSignup={() => setAuthView('signup')} />
    ) : (
      <Signup
        onSwitchToLogin={() => setAuthView('login')}
        onComplete={() => setNeedsOnboarding(true)}
      />
    );
  }

  if (needsOnboarding) {
    return <Onboarding onComplete={handleOnboardingComplete} />;
  }

  return (
    <>
      <AppLayout
        currentView={currentView}
        onNavigate={handleNavigate}
        onStartSession={() => setShowActiveSession(true)}
      >
        {currentView === 'home' && <Home key={`home-${refreshKey}`} />}
        {currentView === 'profile' && <Profile key={`profile-${refreshKey}`} onNavigateToLibrary={() => handleNavigate('library')} />}
        {currentView === 'library' && <Library key={`library-${refreshKey}`} onNavigateToSearch={() => handleNavigate('search')} />}
        {currentView === 'insights' && <Insights key={`insights-${refreshKey}`} />}
        {currentView === 'search' && <Search key={`search-${refreshKey}`} />}
      </AppLayout>

      {showActiveSession && (
        <ActiveSession
          onCancel={() => setShowActiveSession(false)}
          onFinish={handleSessionFinish}
        />
      )}
    </>
  );
}

export default App;
