import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { ActivityCard } from '../components/ActivityCard';
import { CommentModal } from '../components/CommentModal';
import { NotificationsModal } from '../components/NotificationsModal';
import { SearchUsersModal } from '../components/SearchUsersModal';
import { Flame, Bell, UserPlus } from 'lucide-react';

type FeedFilter = 'all' | 'following' | 'me';

export function Home() {
  const [activities, setActivities] = useState<any[]>([]);
  const [filter, setFilter] = useState<FeedFilter>('all');
  const [loading, setLoading] = useState(true);
  const [streak, setStreak] = useState(0);
  const [commentingActivityId, setCommentingActivityId] = useState<string | null>(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showSearchUsers, setShowSearchUsers] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    loadActivities();
    loadStreak();
  }, [filter, user]);

  const loadActivities = async () => {
    if (!user) return;

    setLoading(true);

    const { data: following } = await supabase
      .from('follows')
      .select('following_id')
      .eq('follower_id', user.id);

    const followingIds = following?.map((f) => f.following_id) || [];

    let query = supabase
      .from('activities')
      .select(`
        *,
        user_profiles!activities_user_id_fkey(username, display_name, avatar_url),
        books(title, author, cover_url)
      `)
      .order('created_at', { ascending: false })
      .limit(20);

    if (filter === 'me') {
      query = query.eq('user_id', user.id);
    } else if (filter === 'following') {
      if (followingIds.length > 0) {
        query = query.in('user_id', followingIds).or(`visibility.eq.public,and(visibility.eq.followers,user_id.in.(${followingIds.join(',')}))`);
      } else {
        setActivities([]);
        setLoading(false);
        return;
      }
    } else {
      query = query.or(`visibility.eq.public,user_id.eq.${user.id},and(visibility.eq.followers,user_id.in.(${followingIds.join(',')}))`);
    }

    const { data } = await query;

    if (data) {
      const activitiesWithReactions = await Promise.all(
        data.map(async (activity) => {
          const { count: reactionsCount } = await supabase
            .from('activity_reactions')
            .select('*', { count: 'exact', head: true })
            .eq('activity_id', activity.id);

          const { count: commentsCount } = await supabase
            .from('activity_comments')
            .select('*', { count: 'exact', head: true })
            .eq('activity_id', activity.id);

          const { data: userReaction } = await supabase
            .from('activity_reactions')
            .select('id')
            .eq('activity_id', activity.id)
            .eq('user_id', user.id)
            .maybeSingle();

          return {
            id: activity.id,
            user: activity.user_profiles,
            type: activity.type,
            title: activity.title,
            pages_read: activity.pages_read,
            duration_minutes: activity.duration_minutes,
            notes: activity.notes,
            quotes: activity.quotes || [],
            book: activity.books,
            created_at: activity.created_at,
            reactions_count: reactionsCount || 0,
            comments_count: commentsCount || 0,
            user_has_reacted: !!userReaction,
          };
        })
      );

      setActivities(activitiesWithReactions);
    }

    setLoading(false);
  };

  const loadStreak = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('user_profiles')
      .select('current_streak')
      .eq('id', user.id)
      .single();

    if (data) {
      setStreak(data.current_streak);
    }
  };

  const handleReact = async (activityId: string) => {
    if (!user) return;

    const activity = activities.find((a) => a.id === activityId);
    if (!activity) return;

    if (activity.user_has_reacted) {
      await supabase
        .from('activity_reactions')
        .delete()
        .eq('activity_id', activityId)
        .eq('user_id', user.id);
    } else {
      await supabase
        .from('activity_reactions')
        .insert({ activity_id: activityId, user_id: user.id, type: 'like' });
    }

    loadActivities();
  };

  const handleComment = (activityId: string) => {
    setCommentingActivityId(activityId);
  };

  const handleCloseComments = () => {
    setCommentingActivityId(null);
    loadActivities();
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-0 bg-stone-50 z-10 border-b border-stone-200">
        <div className="px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold tracking-tight">Fil d'actualité</h1>
            <div className="flex items-center gap-2">
              {streak > 0 && (
                <div className="flex items-center gap-1.5 bg-lime-400 px-3 py-1.5 rounded-full">
                  <Flame className="w-4 h-4 text-stone-900" />
                  <span className="font-semibold text-sm text-stone-900">{streak}</span>
                </div>
              )}
              <button
                onClick={() => setShowSearchUsers(true)}
                className="p-2 hover:bg-black/5 rounded-full transition-colors"
                title="Ajouter des amis"
              >
                <UserPlus className="w-5 h-5 text-text-sub-light" />
              </button>
              <button
                onClick={() => setShowNotifications(true)}
                className="p-2 hover:bg-black/5 rounded-full transition-colors"
                title="Notifications"
              >
                <Bell className="w-5 h-5 text-text-sub-light" />
              </button>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setFilter('all')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                filter === 'all'
                  ? 'bg-stone-900 text-white'
                  : 'bg-white text-stone-600 border border-stone-200'
              }`}
            >
              Tous
            </button>
            <button
              onClick={() => setFilter('following')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                filter === 'following'
                  ? 'bg-stone-900 text-white'
                  : 'bg-white text-stone-600 border border-stone-200'
              }`}
            >
              Abonnements
            </button>
            <button
              onClick={() => setFilter('me')}
              className={`px-4 py-2 rounded-lg font-medium transition-colors ${
                filter === 'me'
                  ? 'bg-stone-900 text-white'
                  : 'bg-white text-stone-600 border border-stone-200'
              }`}
            >
              Moi
            </button>
          </div>
        </div>
      </div>

      <div className="p-4">
        {loading ? (
          <div className="text-center py-12 text-stone-500">Chargement des activités...</div>
        ) : activities.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-stone-600 mb-2">Aucune activité pour le moment</p>
            <p className="text-sm text-stone-500">
              {filter === 'following'
                ? 'Suivez des utilisateurs pour voir leurs activités'
                : 'Commencez à enregistrer vos activités pour construire votre fil'}
            </p>
          </div>
        ) : (
          activities.map((activity) => (
            <ActivityCard
              key={activity.id}
              activity={activity}
              onReact={() => handleReact(activity.id)}
              onComment={() => handleComment(activity.id)}
            />
          ))
        )}
      </div>

      {commentingActivityId && (
        <CommentModal
          activityId={commentingActivityId}
          onClose={handleCloseComments}
        />
      )}

      {showNotifications && (
        <NotificationsModal onClose={() => setShowNotifications(false)} />
      )}

      {showSearchUsers && (
        <SearchUsersModal onClose={() => setShowSearchUsers(false)} />
      )}
    </div>
  );
}
