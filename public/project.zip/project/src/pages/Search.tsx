import { useState } from 'react';
import { Search as SearchIcon, Book as BookIcon } from 'lucide-react';
import { searchBooks, type Book } from '../lib/googleBooks';
import { BookDetail } from '../components/BookDetail';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';

export function Search() {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Book[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedBook, setSelectedBook] = useState<Book | null>(null);
  const [adding, setAdding] = useState<string | null>(null);
  const { user } = useAuth();

  const handleSearch = async (searchQuery: string) => {
    setQuery(searchQuery);

    if (searchQuery.length < 2) {
      setResults([]);
      return;
    }

    setLoading(true);
    const books = await searchBooks(searchQuery);
    setResults(books);
    setLoading(false);
  };

  const handleAddBook = async (book: Book) => {
    if (!user) return;

    setAdding(book.id);

    const existingInDB = await supabase
      .from('books')
      .select('id')
      .eq('isbn', book.isbn)
      .maybeSingle();

    let bookId;

    if (existingInDB.data) {
      bookId = existingInDB.data.id;
    } else {
      const { data: newBook, error } = await supabase
        .from('books')
        .insert({
          title: book.title,
          author: book.authors,
          total_pages: book.pageCount || 0,
          cover_url: book.thumbnail,
          isbn: book.isbn,
          publisher: book.publisher,
          genre: book.category,
          description: book.description,
        })
        .select()
        .single();

      if (error || !newBook) {
        console.error('Error adding book to database:', error);
        setAdding(null);
        return;
      }

      bookId = newBook.id;
    }

    const { data: existingUserBook } = await supabase
      .from('user_books')
      .select('id')
      .eq('user_id', user.id)
      .eq('book_id', bookId)
      .maybeSingle();

    if (existingUserBook) {
      alert('Ce livre est déjà dans votre bibliothèque!');
      setAdding(null);
      return;
    }

    await supabase.from('user_books').insert({
      user_id: user.id,
      book_id: bookId,
      status: 'reading',
      current_page: 0,
    });

    setAdding(null);
    alert('Livre ajouté à votre bibliothèque!');
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-0 bg-background-light z-10 border-b border-gray-200">
        <div className="p-4">
          <h1 className="text-2xl font-bold mb-4">Rechercher un livre</h1>
          <div className="relative">
            <SearchIcon className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-text-sub-light" />
            <input
              type="text"
              placeholder="Titre, auteur, ISBN..."
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent bg-white"
              value={query}
              onChange={(e) => handleSearch(e.target.value)}
            />
          </div>
        </div>
      </div>

      <div className="p-4">
        {loading && (
          <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            <p className="mt-4 text-text-sub-light">Recherche en cours...</p>
          </div>
        )}

        {!loading && query.length >= 2 && results.length === 0 && (
          <div className="text-center py-12 text-text-sub-light">
            <BookIcon className="w-16 h-16 mx-auto mb-4 text-text-sub-light" />
            <p className="text-lg font-medium">Aucun livre trouvé</p>
            <p className="text-sm mt-2">Essayez une autre recherche</p>
          </div>
        )}

        {!loading && results.length > 0 && (
          <div className="space-y-3">
            {results.map((book) => (
              <div
                key={book.id}
                className="flex gap-4 p-4 bg-card-light rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-shadow"
              >
                <div
                  className="w-20 shrink-0 aspect-[2/3] rounded-lg overflow-hidden bg-gray-200 shadow-md cursor-pointer hover:scale-105 transition-transform"
                  onClick={() => setSelectedBook(book)}
                >
                  {book.thumbnail ? (
                    <img
                      src={book.thumbnail}
                      alt={book.title}
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.parentElement!.innerHTML = `
                          <div class="w-full h-full flex items-center justify-center">
                            <svg class="w-8 h-8 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" />
                            </svg>
                          </div>
                        `;
                      }}
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <BookIcon className="w-8 h-8 text-text-sub-light" />
                    </div>
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <h3
                    className="font-bold text-text-main-light mb-1 line-clamp-2 cursor-pointer hover:text-primary"
                    onClick={() => setSelectedBook(book)}
                  >
                    {book.title}
                  </h3>
                  <p className="text-sm text-text-sub-light mb-2 truncate">{book.authors}</p>

                  <div className="flex flex-wrap gap-2">
                    {book.category && (
                      <span className="inline-block text-xs bg-primary/20 text-primary px-2 py-1 rounded-full font-medium">
                        {book.category}
                      </span>
                    )}
                    {book.pageCount && (
                      <span className="inline-block text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded-full font-medium">
                        {book.pageCount} pages
                      </span>
                    )}
                  </div>
                </div>

                <button
                  onClick={() => handleAddBook(book)}
                  disabled={adding === book.id}
                  className="shrink-0 h-10 px-4 bg-primary text-black rounded-lg font-bold hover:brightness-95 transition-all text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {adding === book.id ? 'Ajout...' : 'Ajouter'}
                </button>
              </div>
            ))}
          </div>
        )}

        {query.length === 0 && (
          <div className="text-center py-12 text-text-sub-light">
            <SearchIcon className="w-16 h-16 mx-auto mb-4 text-text-sub-light" />
            <p className="text-lg font-medium">Recherchez un livre</p>
            <p className="text-sm mt-2">Tapez un titre, un auteur ou un ISBN</p>
          </div>
        )}
      </div>

      {selectedBook && (
        <BookDetail book={selectedBook} onClose={() => setSelectedBook(null)} onAdd={handleAddBook} />
      )}
    </div>
  );
}
