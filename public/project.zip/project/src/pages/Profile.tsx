import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Flame, BookOpen, Clock, TrendingUp, LogOut, Library, Edit, Users, Bell, UserPlus, Settings } from 'lucide-react';
import { Clubs } from './Clubs';
import { EditProfileModal } from '../components/EditProfileModal';
import { NotificationsModal } from '../components/NotificationsModal';
import { NotificationSettingsModal } from '../components/NotificationSettingsModal';
import { SearchUsersModal } from '../components/SearchUsersModal';
import { BookDetailsWithManagement } from '../components/BookDetailsWithManagement';

interface ProfileProps {
  onNavigateToLibrary: () => void;
}

export function Profile({ onNavigateToLibrary }: ProfileProps) {
  const [profile, setProfile] = useState<any>(null);
  const [stats, setStats] = useState({ followers: 0, following: 0, activities: 0, books: 0 });
  const [loading, setLoading] = useState(true);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [showClubs, setShowClubs] = useState(false);
  const [clubCount, setClubCount] = useState(0);
  const [weeklyActivity, setWeeklyActivity] = useState<number[]>([0, 0, 0, 0, 0, 0, 0]);
  const [showNotifications, setShowNotifications] = useState(false);
  const [showNotificationSettings, setShowNotificationSettings] = useState(false);
  const [showSearchUsers, setShowSearchUsers] = useState(false);
  const [currentlyReading, setCurrentlyReading] = useState<any[]>([]);
  const [selectedBookId, setSelectedBookId] = useState<string | null>(null);
  const { user, signOut } = useAuth();

  useEffect(() => {
    loadProfile();
    loadStats();
    loadClubCount();
    loadWeeklyActivity();
    loadCurrentlyReading();

    const interval = setInterval(() => {
      loadWeeklyActivity();
      loadStats();
    }, 30000);

    return () => clearInterval(interval);
  }, [user]);

  const loadProfile = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('user_profiles')
      .select('*')
      .eq('id', user.id)
      .single();

    if (data) {
      setProfile(data);
    }
    setLoading(false);
  };

  const loadStats = async () => {
    if (!user) return;

    const { count: followersCount } = await supabase
      .from('follows')
      .select('*', { count: 'exact', head: true })
      .eq('following_id', user.id);

    const { count: followingCount } = await supabase
      .from('follows')
      .select('*', { count: 'exact', head: true })
      .eq('follower_id', user.id);

    const { count: activitiesCount } = await supabase
      .from('activities')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id);

    const { count: booksCount } = await supabase
      .from('user_books')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id);

    setStats({
      followers: followersCount || 0,
      following: followingCount || 0,
      activities: activitiesCount || 0,
      books: booksCount || 0,
    });
  };

  const loadClubCount = async () => {
    if (!user) return;

    const { count } = await supabase
      .from('club_members')
      .select('*', { count: 'exact', head: true })
      .eq('user_id', user.id);

    setClubCount(count || 0);
  };

  const loadWeeklyActivity = async () => {
    if (!user) {
      console.log('No user, skipping weekly activity load');
      return;
    }

    try {
      const today = new Date();
      const dayOfWeek = today.getDay();
      const startOfWeek = new Date(today);
      startOfWeek.setDate(today.getDate() - dayOfWeek);
      startOfWeek.setHours(0, 0, 0, 0);

      const { data: activities, error } = await supabase
        .from('activities')
        .select('pages_read, created_at')
        .eq('user_id', user.id)
        .gte('created_at', startOfWeek.toISOString())
        .order('created_at', { ascending: true });

      console.log('=== Weekly Activity Debug ===');
      console.log('User ID:', user.id);
      console.log('Today:', today.toString());
      console.log('Current day of week:', dayOfWeek, ['D', 'L', 'M', 'M', 'J', 'V', 'S'][dayOfWeek]);
      console.log('Start of week:', startOfWeek.toISOString());
      console.log('Raw activities:', JSON.stringify(activities, null, 2));
      console.log('Activities found:', activities?.length || 0);
      if (error) console.error('Error loading activities:', error);

      const weekData = [0, 0, 0, 0, 0, 0, 0];

      if (activities && activities.length > 0) {
        activities.forEach((activity) => {
          const activityDate = new Date(activity.created_at);
          const dayIndex = activityDate.getDay();
          const pagesRead = activity.pages_read || 0;
          console.log('Processing activity:', {
            created_at: activity.created_at,
            activityDate: activityDate.toString(),
            dayIndex,
            dayLabel: ['D', 'L', 'M', 'M', 'J', 'V', 'S'][dayIndex],
            pagesRead,
            currentValue: weekData[dayIndex]
          });
          weekData[dayIndex] += pagesRead;
          console.log('New value for day', dayIndex, ':', weekData[dayIndex]);
        });
      }

      console.log('Final week data:', weekData);
      console.log('Total pages:', weekData.reduce((a, b) => a + b, 0));
      console.log('Setting state with:', weekData);
      setWeeklyActivity([...weekData]);
      console.log('State updated');
    } catch (err) {
      console.error('Error in loadWeeklyActivity:', err);
    }
  };

  const loadCurrentlyReading = async () => {
    if (!user) return;

    const { data } = await supabase
      .from('user_books')
      .select('books(id, title, author, cover_url), current_page, total_pages')
      .eq('user_id', user.id)
      .eq('status', 'reading')
      .limit(4);

    if (data) {
      setCurrentlyReading(data);
    }
  };

  const handleSignOut = async () => {
    await signOut();
  };

  if (loading || !profile) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background-light">
        <div className="text-text-sub-light">Chargement du profil...</div>
      </div>
    );
  }

  if (showClubs) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="sticky top-0 bg-background-light/90 backdrop-blur-md z-10 border-b border-gray-200 px-4 py-3 flex items-center gap-3">
          <button
            onClick={() => {
              setShowClubs(false);
              loadClubCount();
            }}
            className="p-2 hover:bg-black/5 rounded-full transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h2 className="text-lg font-bold">Retour au profil</h2>
        </div>
        <Clubs />
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-0 bg-background-light/90 backdrop-blur-md z-10 border-b border-gray-200 px-4 py-3 flex items-center justify-between">
        <h2 className="text-lg font-bold">Profil</h2>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowSearchUsers(true)}
            className="p-2 hover:bg-black/5 rounded-full transition-colors"
            title="Ajouter des amis"
          >
            <UserPlus className="w-5 h-5 text-text-sub-light" />
          </button>
          <button
            onClick={() => setShowNotifications(true)}
            className="p-2 hover:bg-black/5 rounded-full transition-colors relative"
            title="Notifications"
          >
            <Bell className="w-5 h-5 text-text-sub-light" />
          </button>
          <button
            onClick={handleSignOut}
            className="p-2 hover:bg-black/5 rounded-full transition-colors"
            title="Se déconnecter"
          >
            <LogOut className="w-5 h-5 text-text-sub-light" />
          </button>
        </div>
      </div>

      <div className="px-4 pt-4 pb-6">
        <div className="flex flex-col items-center text-center mb-6">
          <div className="relative mb-4">
            <div className="w-32 h-32 bg-gray-200 rounded-full flex items-center justify-center text-4xl font-bold text-text-main-light border-4 border-white shadow-lg overflow-hidden">
              {profile.avatar_url ? (
                <img src={profile.avatar_url} alt={profile.display_name} className="w-full h-full object-cover" />
              ) : (
                profile.display_name.charAt(0).toUpperCase()
              )}
            </div>
            {profile.current_streak > 0 && (
              <div className="absolute bottom-0 right-0 bg-primary text-black rounded-full p-1.5 border-4 border-background-light flex items-center justify-center">
                <Flame className="w-5 h-5 fill-black" />
              </div>
            )}
          </div>
          <h1 className="text-2xl font-bold tracking-tight mb-1">{profile.display_name}</h1>
          <p className="text-text-sub-light text-sm mb-3">@{profile.username}</p>
          {profile.bio && (
            <p className="text-text-sub-light text-sm max-w-md mb-4">{profile.bio}</p>
          )}
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsEditModalOpen(true)}
              className="flex items-center gap-2 px-6 py-2.5 bg-stone-900 text-white rounded-xl hover:bg-stone-800 transition-colors font-medium"
            >
              <Edit className="w-4 h-4" />
              Modifier le profil
            </button>
            <button
              onClick={() => setShowNotificationSettings(true)}
              className="flex items-center gap-2 px-4 py-2.5 bg-card-light border-2 border-gray-200 text-text-main-light rounded-xl hover:bg-gray-50 transition-colors font-medium"
              title="Paramètres de notifications"
            >
              <Settings className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-2.5 mb-5">
          <button className="flex flex-col items-center justify-center gap-1 rounded-xl p-3 bg-card-light border border-gray-200 shadow-sm hover:shadow-md transition-all aspect-square">
            <p className="text-2xl font-bold leading-none text-text-main-light">{stats.followers}</p>
            <p className="text-[10px] text-text-sub-light font-medium text-center">Abonnés</p>
          </button>

          <button className="flex flex-col items-center justify-center gap-1 rounded-xl p-3 bg-card-light border border-gray-200 shadow-sm hover:shadow-md transition-all aspect-square">
            <p className="text-2xl font-bold leading-none text-text-main-light">{stats.following}</p>
            <p className="text-[10px] text-text-sub-light font-medium text-center">Abonnements</p>
          </button>

          <button
            onClick={onNavigateToLibrary}
            className="flex flex-col items-center justify-center gap-1 rounded-xl p-3 bg-card-light border border-gray-200 shadow-sm hover:shadow-md transition-all aspect-square"
          >
            <p className="text-2xl font-bold leading-none text-text-main-light">{stats.books}</p>
            <p className="text-[10px] text-text-sub-light font-medium text-center">Livres</p>
          </button>

          <div className="flex flex-col items-center justify-center gap-1 rounded-xl p-3 bg-primary text-black border border-primary shadow-md relative overflow-hidden aspect-square">
            <div className="absolute inset-0 opacity-10 flex items-center justify-center rotate-12">
              <Flame className="w-16 h-16" />
            </div>
            <p className="text-2xl font-bold leading-none relative z-10">{profile.current_streak}</p>
            <p className="text-[10px] text-black/70 font-bold relative z-10 text-center">Série</p>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 mb-6">
          <div className="flex flex-col gap-1 rounded-xl p-5 bg-card-light border border-gray-200 shadow-sm">
            <div className="flex items-center gap-2 text-text-sub-light mb-1">
              <BookOpen className="w-5 h-5" />
              <p className="text-xs font-bold uppercase tracking-wide">Pages</p>
            </div>
            <p className="text-3xl font-bold leading-none text-text-main-light">
              {(profile.total_pages_read / 1000).toFixed(1)}k
            </p>
            <p className="text-xs text-text-sub-light">Total lues</p>
          </div>

          <div className="flex flex-col gap-1 rounded-xl p-5 bg-card-light border border-gray-200 shadow-sm">
            <div className="flex items-center gap-2 text-text-sub-light mb-1">
              <Clock className="w-5 h-5" />
              <p className="text-xs font-bold uppercase tracking-wide">Heures</p>
            </div>
            <p className="text-3xl font-bold leading-none text-text-main-light">{profile.total_hours_logged}</p>
            <p className="text-xs text-text-sub-light">Temps passé</p>
          </div>
        </div>

        <div className="mb-6">
          <div className="flex items-center justify-between mb-4 px-1">
            <h4 className="text-sm font-bold uppercase tracking-wider text-text-sub-light">Activité hebdomadaire</h4>
            <span className="text-xs font-medium bg-gray-100 px-2 py-1 rounded text-gray-600">
              {weeklyActivity.reduce((a, b) => a + b, 0)} Pages
            </span>
          </div>
          <div className="bg-card-light p-6 rounded-2xl border border-gray-200 shadow-sm">
            <div className="flex gap-4">
              <div className="flex flex-col justify-between h-40 py-1">
                {(() => {
                  const maxPages = Math.max(...weeklyActivity, 10);
                  const step = Math.ceil(maxPages / 4);
                  const yLabels = [step * 4, step * 3, step * 2, step, 0];
                  console.log('Rendering chart - weeklyActivity:', weeklyActivity, 'maxPages:', maxPages);
                  return yLabels.map((value, idx) => (
                    <span key={idx} className="text-[10px] text-gray-400 font-medium">{value}</span>
                  ));
                })()}
              </div>

              <div className="flex-1 flex items-end justify-between h-40 gap-2">
                {['D', 'L', 'M', 'M', 'J', 'V', 'S'].map((day, index) => {
                  const maxPages = Math.max(...weeklyActivity, 10);
                  const pages = weeklyActivity[index];
                  const heightPercent = maxPages > 0 ? (pages / maxPages) * 100 : 0;
                  console.log(`Day ${day} (${index}): pages=${pages}, height=${heightPercent}%`);
                  const today = new Date().getDay();
                  const isToday = index === today;

                  return (
                    <div key={index} className="flex flex-col items-center gap-2 flex-1 group">
                      <div className="w-full bg-gray-100 rounded-t-lg relative h-full flex items-end overflow-hidden">
                        {pages > 0 ? (
                          <div
                            className={`w-full rounded-t-lg transition-all duration-300 relative ${
                              isToday
                                ? 'bg-primary shadow-[0_0_15px_rgba(249,245,6,0.4)]'
                                : 'bg-primary/60 group-hover:bg-primary'
                            }`}
                            style={{ height: `${Math.max(heightPercent, 10)}%` }}
                          >
                            <span className="absolute -top-6 left-1/2 -translate-x-1/2 text-xs font-bold text-text-main-light opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap bg-white px-2 py-0.5 rounded shadow-sm">
                              {pages}p
                            </span>
                          </div>
                        ) : (
                          <div className="w-full h-1 bg-gray-200 rounded-t-lg"></div>
                        )}
                      </div>
                      <span className={`text-[10px] font-bold uppercase ${isToday ? 'text-text-main-light' : 'text-gray-400'}`}>
                        {day}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {currentlyReading.length > 0 && (
          <div className="bg-card-light rounded-xl border border-gray-200 p-5 shadow-sm mb-4">
            <h2 className="text-sm font-bold uppercase tracking-wider text-text-sub-light mb-4">En cours de lecture</h2>
            <div className="grid grid-cols-4 gap-3">
              {currentlyReading.map((item: any) => {
                const book = item.books;
                const progress = item.total_pages > 0 ? Math.round((item.current_page / item.total_pages) * 100) : 0;
                return (
                  <button
                    key={book.id}
                    onClick={() => setSelectedBookId(book.id)}
                    className="flex flex-col items-center"
                  >
                    <div className="relative w-full aspect-[2/3] mb-2 rounded-lg overflow-hidden shadow-md group cursor-pointer hover:shadow-xl transition-shadow">
                      {book.cover_url ? (
                        <img
                          src={book.cover_url}
                          alt={book.title}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full bg-gradient-to-br from-gray-200 to-gray-300 flex items-center justify-center">
                          <BookOpen className="w-8 h-8 text-gray-400" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-end p-2">
                        <div className="text-white text-xs font-bold mb-1">{progress}%</div>
                        <div className="text-white text-[9px] text-center line-clamp-2 font-medium">{book.title}</div>
                      </div>
                    </div>
                    <div className="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary transition-all"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {profile.interests && profile.interests.length > 0 && (
          <div className="bg-card-light rounded-xl border border-gray-200 p-5 shadow-sm mb-4">
            <h2 className="text-sm font-bold uppercase tracking-wider text-text-sub-light mb-3">Centres d'intérêt</h2>
            <div className="flex flex-wrap gap-2">
              {profile.interests.map((interest: string) => (
                <span
                  key={interest}
                  className="px-3 py-1.5 bg-gray-100 text-text-main-light rounded-lg text-sm font-medium"
                >
                  {interest}
                </span>
              ))}
            </div>
          </div>
        )}

        <button
          onClick={() => setShowClubs(true)}
          className="w-full bg-card-light rounded-xl border border-gray-200 p-5 shadow-sm hover:shadow-md transition-all hover:border-lime-300"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-lime-100 rounded-full flex items-center justify-center">
                <Users className="w-6 h-6 text-lime-800" />
              </div>
              <div className="text-left">
                <h3 className="font-bold text-text-main-light mb-0.5">Mes clubs</h3>
                <p className="text-sm text-text-sub-light">
                  {clubCount === 0 ? 'Rejoignez des clubs de lecture' : `${clubCount} club${clubCount !== 1 ? 's' : ''}`}
                </p>
              </div>
            </div>
            <svg className="w-5 h-5 text-text-sub-light" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
            </svg>
          </div>
        </button>
      </div>

      {isEditModalOpen && (
        <EditProfileModal
          profile={profile}
          onClose={() => setIsEditModalOpen(false)}
          onSave={() => {
            loadProfile();
            loadStats();
          }}
        />
      )}

      {showNotifications && (
        <NotificationsModal onClose={() => setShowNotifications(false)} />
      )}

      {showNotificationSettings && (
        <NotificationSettingsModal onClose={() => setShowNotificationSettings(false)} />
      )}

      {showSearchUsers && (
        <SearchUsersModal onClose={() => setShowSearchUsers(false)} />
      )}

      {selectedBookId && (
        <BookDetailsWithManagement
          bookId={selectedBookId}
          onClose={() => {
            setSelectedBookId(null);
            loadCurrentlyReading();
            loadStats();
          }}
        />
      )}
    </div>
  );
}
