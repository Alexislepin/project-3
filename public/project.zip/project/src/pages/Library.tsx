import { useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Book, X, Search as SearchIcon, TrendingUp, Scan, MoreVertical } from 'lucide-react';
import { BookDetailsWithManagement } from '../components/BookDetailsWithManagement';
import { BookDetailsModal } from '../components/BookDetailsModal';
import { BarcodeScanner } from '../components/BarcodeScanner';
import { AddBookStatusModal } from '../components/AddBookStatusModal';
import { ManageBookModal } from '../components/ManageBookModal';
import { searchBooks, Book as GoogleBook } from '../lib/googleBooks';

type BookStatus = 'reading' | 'completed' | 'want_to_read';
type FilterType = BookStatus | 'explore';

interface LibraryProps {
  onNavigateToSearch?: () => void;
}

export function Library({ onNavigateToSearch }: LibraryProps) {
  const [userBooks, setUserBooks] = useState<any[]>([]);
  const [filter, setFilter] = useState<FilterType>('reading');
  const [loading, setLoading] = useState(true);
  const [detailsBookId, setDetailsBookId] = useState<string | null>(null);
  const [exploreBooks, setExploreBooks] = useState<GoogleBook[]>([]);
  const [exploreGenre, setExploreGenre] = useState<string>('popular');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<GoogleBook[]>([]);
  const [searching, setSearching] = useState(false);
  const [addingBookId, setAddingBookId] = useState<string | null>(null);
  const [showScanner, setShowScanner] = useState(false);
  const [bookToAdd, setBookToAdd] = useState<GoogleBook | null>(null);
  const [bookToManage, setBookToManage] = useState<any>(null);
  const [selectedBookDetails, setSelectedBookDetails] = useState<GoogleBook | null>(null);
  const { user } = useAuth();

  useEffect(() => {
    if (filter === 'explore') {
      loadExploreBooks();
    } else {
      loadUserBooks();
    }
  }, [filter, user]);

  useEffect(() => {
    if (filter === 'explore') {
      loadExploreBooks();
    }
  }, [exploreGenre]);

  const loadUserBooks = async () => {
    if (!user) return;

    setLoading(true);

    const { data } = await supabase
      .from('user_books')
      .select('*, books(*)')
      .eq('user_id', user.id)
      .eq('status', filter as BookStatus)
      .order('updated_at', { ascending: false });

    if (data) {
      setUserBooks(data);
    }

    setLoading(false);
  };

  const loadExploreBooks = async () => {
    setLoading(true);

    try {
      const genreSearches: Record<string, string[]> = {
        popular: [
          'Harry Potter J.K. Rowling',
          'Game of Thrones George R.R. Martin',
          'The Hunger Games Suzanne Collins',
          'Twilight Stephenie Meyer',
          '1984 George Orwell',
          'To Kill a Mockingbird Harper Lee',
          'Pride and Prejudice Jane Austen',
          'The Great Gatsby F. Scott Fitzgerald',
          'The Lord of the Rings J.R.R. Tolkien',
          'The Hobbit J.R.R. Tolkien',
          'Dune Frank Herbert',
          'The Da Vinci Code Dan Brown',
          'Gone Girl Gillian Flynn',
          'The Girl with the Dragon Tattoo Stieg Larsson',
          'The Alchemist Paulo Coelho',
          'Life of Pi Yann Martel',
          'The Kite Runner Khaled Hosseini',
          'The Book Thief Markus Zusak',
          'The Fault in Our Stars John Green',
          'Divergent Veronica Roth',
          'Percy Jackson Rick Riordan',
          'A Song of Ice and Fire',
          'Stephen King bestsellers',
          'Agatha Christie bestsellers',
          'Sherlock Holmes Arthur Conan Doyle',
          'The Chronicles of Narnia C.S. Lewis',
          'subject:fiction bestseller',
          'The Hunger Games',
          'Maze Runner James Dashner',
          'Fifty Shades E.L. James'
        ],
        fiction: [
          'subject:fiction bestseller',
          'literary fiction bestseller',
          'contemporary fiction bestseller',
          'The Catcher in the Rye',
          'Brave New World Aldous Huxley',
          'Animal Farm George Orwell',
          'Lord of the Flies William Golding',
          'The Handmaid\'s Tale Margaret Atwood',
          'American Gods Neil Gaiman',
          'The Road Cormac McCarthy',
          'Cloud Atlas David Mitchell',
          'Never Let Me Go Kazuo Ishiguro'
        ],
        romance: [
          'subject:romance bestseller',
          'Pride and Prejudice Jane Austen',
          'Me Before You Jojo Moyes',
          'The Notebook Nicholas Sparks',
          'Outlander Diana Gabaldon',
          'Twilight romance',
          'Bridgerton Julia Quinn',
          'Colleen Hoover bestsellers',
          'It Ends with Us Colleen Hoover',
          'Red White and Royal Blue',
          'Beach Read Emily Henry',
          'People We Meet on Vacation Emily Henry'
        ],
        thriller: [
          'subject:thriller bestseller',
          'Gone Girl Gillian Flynn',
          'The Girl on the Train Paula Hawkins',
          'The Da Vinci Code Dan Brown',
          'The Silent Patient Alex Michaelides',
          'Big Little Lies Liane Moriarty',
          'Sharp Objects Gillian Flynn',
          'psychological thriller bestseller',
          'The Woman in the Window',
          'Behind Her Eyes Sarah Pinborough',
          'The Guest List Lucy Foley',
          'Verity Colleen Hoover'
        ],
        fantasy: [
          'subject:fantasy bestseller',
          'Harry Potter J.K. Rowling',
          'The Lord of the Rings J.R.R. Tolkien',
          'A Court of Thorns and Roses Sarah J. Maas',
          'The Hobbit',
          'Game of Thrones George R.R. Martin',
          'The Name of the Wind Patrick Rothfuss',
          'Mistborn Brandon Sanderson',
          'The Witcher Andrzej Sapkowski',
          'Percy Jackson Rick Riordan',
          'Eragon Christopher Paolini',
          'Six of Crows Leigh Bardugo',
          'Throne of Glass Sarah J. Maas'
        ],
        scifi: [
          'subject:science fiction bestseller',
          'Dune Frank Herbert',
          'The Martian Andy Weir',
          'Ender\'s Game Orson Scott Card',
          'Foundation Isaac Asimov',
          'Neuromancer William Gibson',
          'The Hitchhiker\'s Guide Douglas Adams',
          'Ready Player One Ernest Cline',
          'Project Hail Mary Andy Weir',
          'The Three-Body Problem',
          'Snow Crash Neal Stephenson',
          'Hyperion Dan Simmons'
        ],
        mystery: [
          'subject:mystery bestseller',
          'Sherlock Holmes Arthur Conan Doyle',
          'Agatha Christie bestsellers',
          'Murder on the Orient Express',
          'The Girl with the Dragon Tattoo',
          'And Then There Were None',
          'The Hound of the Baskervilles',
          'Big Little Lies Liane Moriarty',
          'The Thursday Murder Club',
          'Knives Out mystery',
          'The Da Vinci Code mystery'
        ],
        classics: [
          'classic literature bestseller',
          'Pride and Prejudice Jane Austen',
          'Jane Eyre Charlotte Bronte',
          'Wuthering Heights Emily Bronte',
          'Great Expectations Charles Dickens',
          'Moby Dick Herman Melville',
          'The Count of Monte Cristo Alexandre Dumas',
          'War and Peace Leo Tolstoy',
          'Anna Karenina Leo Tolstoy',
          'Les Misérables Victor Hugo',
          'The Picture of Dorian Gray Oscar Wilde',
          'Frankenstein Mary Shelley',
          'Dracula Bram Stoker'
        ]
      };

      const searches = genreSearches[exploreGenre] || genreSearches.popular;

      const searchPromises = searches.slice(0, 8).map(query =>
        searchBooks(query).catch(() => [])
      );

      const allResults = await Promise.all(searchPromises);
      const allBooks = allResults.flat();

      const uniqueBooks = allBooks.filter((book, index, self) =>
        index === self.findIndex((b) => b.title === book.title && b.authors === book.authors)
      );

      const booksWithCovers = uniqueBooks.filter(book => book.thumbnail);

      setExploreBooks(booksWithCovers.slice(0, 150));
    } catch (error) {
      console.error('Error loading explore books:', error);
      setExploreBooks([]);
    }

    setLoading(false);
  };

  const getProgress = (currentPage: number, totalPages: number) => {
    if (!totalPages) return 0;
    return Math.round((currentPage / totalPages) * 100);
  };

  const updateStatus = async (userBookId: string, newStatus: BookStatus) => {
    await supabase
      .from('user_books')
      .update({ status: newStatus })
      .eq('id', userBookId);

    loadUserBooks();
  };

  const handleSearch = async (query: string) => {
    setSearchQuery(query);

    if (query.trim().length < 2) {
      setSearchResults([]);
      return;
    }

    setSearching(true);
    const results = await searchBooks(query);
    setSearchResults(results);
    setSearching(false);
  };

  const handleAddBookToLibrary = async (googleBook: GoogleBook, status: BookStatus) => {
    if (!user) return;

    setAddingBookId(googleBook.id);

    try {
      let bookId: string | null = null;

      const { data: existingBook } = await supabase
        .from('books')
        .select('id')
        .eq('title', googleBook.title)
        .eq('author', googleBook.authors)
        .maybeSingle();

      if (existingBook) {
        bookId = existingBook.id;
      } else {
        const { data: newBook } = await supabase
          .from('books')
          .insert({
            title: googleBook.title,
            author: googleBook.authors,
            total_pages: googleBook.pageCount || 0,
            cover_url: googleBook.thumbnail,
            genre: googleBook.category,
            description: googleBook.description,
          })
          .select('id')
          .single();

        if (newBook) {
          bookId = newBook.id;
        }
      }

      if (bookId) {
        const { data: existingUserBook } = await supabase
          .from('user_books')
          .select('id')
          .eq('user_id', user.id)
          .eq('book_id', bookId)
          .maybeSingle();

        if (existingUserBook) {
          return;
        }

        await supabase.from('user_books').insert({
          user_id: user.id,
          book_id: bookId,
          status: status,
          current_page: 0,
        });

        setSearchResults([]);
        setSearchQuery('');
        await loadUserBooks();
      }
    } catch (error) {
      console.error('Error adding book:', error);
      alert('Une erreur est survenue lors de l\'ajout du livre');
    } finally {
      setAddingBookId(null);
    }
  };

  const handleDeleteBook = async (userBookId: string) => {
    if (!user) return;

    await supabase
      .from('user_books')
      .delete()
      .eq('id', userBookId);

    setBookToManage(null);
    loadUserBooks();
  };

  const handleChangeBookStatus = async (userBookId: string, newStatus: BookStatus) => {
    if (!user) return;

    await supabase
      .from('user_books')
      .update({ status: newStatus })
      .eq('id', userBookId);

    setBookToManage(null);
    loadUserBooks();
  };

  const handleBarcodeScan = async (isbn: string) => {
    if (searching) return;

    setShowScanner(false);
    setSearching(true);

    const cleanIsbn = isbn.replace(/[-\s]/g, '');

    try {
      const { data: allBooks, error } = await supabase
        .from('books')
        .select('*')
        .not('isbn', 'is', null);

      if (error) {
        console.error('Error searching local database:', error);
      }

      if (allBooks && allBooks.length > 0) {
        const matchingBook = allBooks.find(book =>
          book.isbn && book.isbn.replace(/[-\s]/g, '') === cleanIsbn
        );

        if (matchingBook) {
          const googleBook: GoogleBook = {
            id: matchingBook.id,
            title: matchingBook.title,
            authors: matchingBook.author,
            category: matchingBook.genre || undefined,
            pageCount: matchingBook.total_pages || undefined,
            publisher: matchingBook.publisher || undefined,
            isbn: matchingBook.isbn || undefined,
            description: matchingBook.description || undefined,
            thumbnail: matchingBook.cover_url || undefined,
          };

          setSearching(false);
          setBookToAdd(googleBook);
          return;
        }
      }

      let results = await searchBooks(`isbn:${cleanIsbn}`);

      if (results.length === 0 && cleanIsbn.length === 13) {
        const isbn10 = cleanIsbn.slice(3, 12);
        results = await searchBooks(`isbn:${isbn10}`);
      }

      if (results.length === 0) {
        results = await searchBooks(cleanIsbn);
      }

      setSearching(false);

      if (results.length > 0) {
        const book = results[0];
        setBookToAdd(book);
      } else {
        alert('Livre non trouvé. Essayez de le chercher manuellement dans la recherche ou créez-le à la main.');
      }
    } catch (error) {
      console.error('Error in barcode scan:', error);
      setSearching(false);
      alert('Une erreur est survenue lors de la recherche');
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="sticky top-0 bg-background-light z-10 border-b border-gray-200">
        <div className="p-4">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-2xl font-bold">Ma Bibliothèque</h1>
            <button
              onClick={() => setShowScanner(true)}
              className="p-2.5 bg-primary text-black rounded-xl hover:brightness-95 transition-all shadow-sm"
              title="Scanner un code-barres"
            >
              <Scan className="w-5 h-5" />
            </button>
          </div>

          <div className="mb-4 relative">
            <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-text-sub-light" />
            <input
              type="text"
              placeholder="Rechercher un livre (titre, auteur...)"
              value={searchQuery}
              onChange={(e) => handleSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent bg-white"
            />
          </div>

          <div className="flex gap-2 overflow-x-auto">
            <button
              onClick={() => setFilter('reading')}
              className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-bold transition-all whitespace-nowrap ${
                filter === 'reading'
                  ? 'bg-primary text-black shadow-sm'
                  : 'bg-gray-100 text-text-sub-light hover:bg-gray-200'
              }`}
            >
              En cours
            </button>
            <button
              onClick={() => setFilter('want_to_read')}
              className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-bold transition-all whitespace-nowrap ${
                filter === 'want_to_read'
                  ? 'bg-primary text-black shadow-sm'
                  : 'bg-gray-100 text-text-sub-light hover:bg-gray-200'
              }`}
            >
              À lire
            </button>
            <button
              onClick={() => setFilter('completed')}
              className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-bold transition-all whitespace-nowrap ${
                filter === 'completed'
                  ? 'bg-primary text-black shadow-sm'
                  : 'bg-gray-100 text-text-sub-light hover:bg-gray-200'
              }`}
            >
              Terminé
            </button>
            <button
              onClick={() => setFilter('explore')}
              className={`flex-1 py-2.5 px-4 rounded-lg text-sm font-bold transition-all whitespace-nowrap ${
                filter === 'explore'
                  ? 'bg-primary text-black shadow-sm'
                  : 'bg-gray-100 text-text-sub-light hover:bg-gray-200'
              }`}
            >
              Explorer
            </button>
          </div>
        </div>
      </div>

      <div className="p-4">
        {searching && !searchQuery && (
          <div className="mb-6">
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-primary mb-2"></div>
              <div className="text-text-sub-light">Recherche du livre...</div>
            </div>
          </div>
        )}

        {searchQuery && (
          <div className="mb-6">
            {searching ? (
              <div className="text-center py-8 text-text-sub-light">Recherche en cours...</div>
            ) : searchResults.length === 0 ? (
              <div className="text-center py-8 text-text-sub-light">
                Aucun résultat pour "{searchQuery}"
              </div>
            ) : (
              <div>
                <h2 className="text-lg font-bold mb-3">Résultats ({searchResults.length})</h2>
                <div className="space-y-3">
                  {searchResults.map((book) => (
                    <div
                      key={book.id}
                      className="flex gap-4 p-4 bg-card-light rounded-xl shadow-sm border border-gray-200"
                    >
                      <div className="w-16 shrink-0 aspect-[2/3] rounded-lg overflow-hidden bg-gray-200 shadow-md">
                        {book.thumbnail ? (
                          <img src={book.thumbnail} alt={book.title} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center">
                            <Book className="w-6 h-6 text-text-sub-light" />
                          </div>
                        )}
                      </div>

                      <div className="flex-1 min-w-0">
                        <h3 className="font-bold text-text-main-light mb-1 line-clamp-2">{book.title}</h3>
                        <p className="text-sm text-text-sub-light mb-3">{book.authors}</p>

                        <button
                          onClick={() => setBookToAdd(book)}
                          disabled={addingBookId === book.id}
                          className="w-full py-2.5 px-4 bg-primary text-black rounded-lg text-sm font-semibold hover:brightness-95 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                          {addingBookId === book.id ? 'Ajout en cours...' : 'Ajouter à ma bibliothèque'}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {!searchQuery && loading ? (
          <div className="text-center py-12 text-text-sub-light">Chargement...</div>
        ) : !searchQuery && filter === 'explore' ? (
          <div>
            <div className="mb-4">
              <h2 className="text-xl font-bold mb-3">Explorer par genre</h2>
              <div className="flex gap-2 overflow-x-auto pb-2">
                <button
                  onClick={() => setExploreGenre('popular')}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-all ${
                    exploreGenre === 'popular'
                      ? 'bg-primary text-black'
                      : 'bg-gray-100 text-text-sub-light hover:bg-gray-200'
                  }`}
                >
                  Populaires
                </button>
                <button
                  onClick={() => setExploreGenre('fiction')}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-all ${
                    exploreGenre === 'fiction'
                      ? 'bg-primary text-black'
                      : 'bg-gray-100 text-text-sub-light hover:bg-gray-200'
                  }`}
                >
                  Fiction
                </button>
                <button
                  onClick={() => setExploreGenre('romance')}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-all ${
                    exploreGenre === 'romance'
                      ? 'bg-primary text-black'
                      : 'bg-gray-100 text-text-sub-light hover:bg-gray-200'
                  }`}
                >
                  Romance
                </button>
                <button
                  onClick={() => setExploreGenre('thriller')}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-all ${
                    exploreGenre === 'thriller'
                      ? 'bg-primary text-black'
                      : 'bg-gray-100 text-text-sub-light hover:bg-gray-200'
                  }`}
                >
                  Thriller
                </button>
                <button
                  onClick={() => setExploreGenre('fantasy')}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-all ${
                    exploreGenre === 'fantasy'
                      ? 'bg-primary text-black'
                      : 'bg-gray-100 text-text-sub-light hover:bg-gray-200'
                  }`}
                >
                  Fantasy
                </button>
                <button
                  onClick={() => setExploreGenre('scifi')}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-all ${
                    exploreGenre === 'scifi'
                      ? 'bg-primary text-black'
                      : 'bg-gray-100 text-text-sub-light hover:bg-gray-200'
                  }`}
                >
                  Science-fiction
                </button>
                <button
                  onClick={() => setExploreGenre('mystery')}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-all ${
                    exploreGenre === 'mystery'
                      ? 'bg-primary text-black'
                      : 'bg-gray-100 text-text-sub-light hover:bg-gray-200'
                  }`}
                >
                  Mystère
                </button>
                <button
                  onClick={() => setExploreGenre('classics')}
                  className={`px-4 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-all ${
                    exploreGenre === 'classics'
                      ? 'bg-primary text-black'
                      : 'bg-gray-100 text-text-sub-light hover:bg-gray-200'
                  }`}
                >
                  Classiques
                </button>
              </div>
            </div>

            {exploreBooks.length === 0 ? (
              <div className="text-center py-12">
                <Book className="w-16 h-16 mx-auto mb-4 text-text-sub-light" />
                <p className="text-lg font-medium text-text-main-light mb-2">Chargement des livres...</p>
              </div>
            ) : (
              <div className="grid grid-cols-3 gap-3">
                {exploreBooks.map((book) => (
                  <div
                    key={book.id}
                    onClick={() => setSelectedBookDetails(book)}
                    className="cursor-pointer hover:scale-105 transition-transform"
                  >
                    <div className="aspect-[2/3] rounded-lg overflow-hidden bg-gray-200 shadow-md mb-2">
                      {book.thumbnail ? (
                        <img src={book.thumbnail} alt={book.title} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <Book className="w-8 h-8 text-text-sub-light" />
                        </div>
                      )}
                    </div>
                    <h3 className="text-xs font-semibold text-text-main-light line-clamp-2">{book.title}</h3>
                    <p className="text-xs text-text-sub-light truncate">{book.authors}</p>
                  </div>
                ))}
              </div>
            )}
          </div>
        ) : !searchQuery && userBooks.length === 0 ? (
          <div className="text-center py-12">
            <Book className="w-16 h-16 mx-auto mb-4 text-text-sub-light" />
            <p className="text-lg font-medium text-text-main-light mb-2">
              {filter === 'reading' && 'Aucun livre en cours'}
              {filter === 'want_to_read' && 'Aucun livre à lire'}
              {filter === 'completed' && 'Aucun livre terminé'}
            </p>
            <p className="text-sm text-text-sub-light mb-4">
              Envie de découvrir de nouveaux livres?
            </p>
            <button
              onClick={() => setFilter('explore')}
              className="px-6 py-3 bg-primary text-black rounded-xl font-bold hover:brightness-95 transition-all inline-flex items-center gap-2"
            >
              <TrendingUp className="w-5 h-5" />
              Explorer
            </button>
          </div>
        ) : !searchQuery && userBooks.length > 0 ? (
          <div className="space-y-3">
            {userBooks.map((userBook) => {
              const book = userBook.books;
              const progress = getProgress(userBook.current_page, book.total_pages);

              return (
                <div
                  key={userBook.id}
                  className="flex gap-4 p-4 bg-card-light rounded-xl shadow-sm border border-gray-200 relative"
                >
                  <button
                    onClick={() => setBookToManage({ ...userBook, book })}
                    className="absolute top-3 right-3 p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                  >
                    <MoreVertical className="w-5 h-5" />
                  </button>

                  <div
                    className="w-20 shrink-0 aspect-[2/3] rounded-lg overflow-hidden bg-gray-200 shadow-md cursor-pointer hover:scale-105 transition-transform"
                    onClick={() => setDetailsBookId(book.id)}
                  >
                    {book.cover_url ? (
                      <img src={book.cover_url} alt={book.title} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <Book className="w-8 h-8 text-text-sub-light" />
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0 pr-8">
                    <h3 className="font-bold text-text-main-light mb-1 line-clamp-2">{book.title}</h3>
                    <p className="text-sm text-text-sub-light mb-2 truncate">{book.author}</p>

                    {filter === 'reading' && book.total_pages > 0 && (
                      <div className="mb-2">
                        <div className="flex items-center justify-between text-xs text-text-sub-light mb-1">
                          <span>
                            {userBook.current_page} / {book.total_pages} pages
                          </span>
                          <span className="font-semibold">{progress}%</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                          <div
                            className="bg-primary h-full rounded-full transition-all"
                            style={{ width: `${progress}%` }}
                          />
                        </div>
                      </div>
                    )}

                    <div className="flex flex-wrap gap-2">
                      {book.genre && (
                        <span className="inline-block text-xs bg-primary/20 text-primary px-2 py-1 rounded-full font-medium">
                          {book.genre}
                        </span>
                      )}
                      {book.total_pages > 0 && (
                        <span className="inline-block text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded-full font-medium">
                          {book.total_pages} pages
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ) : null}
      </div>

      {detailsBookId && (
        <BookDetailsWithManagement
          bookId={detailsBookId}
          onClose={() => {
            setDetailsBookId(null);
            loadUserBooks();
          }}
        />
      )}

      {showScanner && (
        <BarcodeScanner
          onScan={handleBarcodeScan}
          onClose={() => setShowScanner(false)}
        />
      )}

      {selectedBookDetails && (
        <BookDetailsModal
          book={{
            title: selectedBookDetails.title,
            author: selectedBookDetails.authors,
            cover_url: selectedBookDetails.thumbnail,
            genre: selectedBookDetails.category,
            total_pages: selectedBookDetails.pageCount || 0,
            description: selectedBookDetails.description,
            publisher: selectedBookDetails.publisher,
            isbn: selectedBookDetails.isbn,
          }}
          onClose={() => setSelectedBookDetails(null)}
          showAddButton={true}
          onAddToLibrary={() => {
            setBookToAdd(selectedBookDetails);
            setSelectedBookDetails(null);
          }}
        />
      )}

      {bookToAdd && (
        <AddBookStatusModal
          bookTitle={bookToAdd.title}
          onClose={() => setBookToAdd(null)}
          onSelect={async (status) => {
            await handleAddBookToLibrary(bookToAdd, status);
            setBookToAdd(null);
          }}
        />
      )}

      {bookToManage && (
        <ManageBookModal
          bookTitle={bookToManage.book.title}
          currentStatus={bookToManage.status}
          onClose={() => setBookToManage(null)}
          onDelete={() => handleDeleteBook(bookToManage.id)}
          onChangeStatus={(status) => handleChangeBookStatus(bookToManage.id, status)}
        />
      )}
    </div>
  );
}
