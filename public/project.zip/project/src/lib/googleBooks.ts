const GOOGLE_BOOKS_API_KEY = import.meta.env.VITE_GOOGLE_BOOKS_API_KEY;
const GOOGLE_BOOKS_API_URL = 'https://www.googleapis.com/books/v1/volumes';

export interface Book {
  id: string;
  title: string;
  authors: string;
  category?: string;
  pageCount?: number;
  publisher?: string;
  isbn?: string;
  description?: string;
  thumbnail?: string;
}

function normalizeImageUrl(url?: string): string | undefined {
  if (!url) return undefined;
  return url.startsWith('http://') ? url.replace('http://', 'https://') : url;
}

function normalizeBook(item: any): Book {
  const volumeInfo = item.volumeInfo || {};

  const authors = volumeInfo.authors || [];
  const authorsString = authors.length > 0 ? authors.join(', ') : 'Auteur inconnu';

  const identifiers = volumeInfo.industryIdentifiers || [];
  const isbn13 = identifiers.find((id: any) => id.type === 'ISBN_13');
  const isbn10 = identifiers.find((id: any) => id.type === 'ISBN_10');
  const isbn = isbn13?.identifier || isbn10?.identifier;

  const imageLinks = volumeInfo.imageLinks || {};
  const thumbnailUrl = imageLinks.thumbnail || imageLinks.smallThumbnail;
  const thumbnail = normalizeImageUrl(thumbnailUrl);

  const categories = volumeInfo.categories || [];
  const category = categories.length > 0 ? categories[0] : undefined;

  const description = volumeInfo.description || undefined;
  const pageCount = volumeInfo.pageCount || undefined;
  const publisher = volumeInfo.publisher || undefined;

  const title = volumeInfo.title || 'Titre inconnu';

  return {
    id: item.id,
    title,
    authors: authorsString,
    category,
    pageCount,
    publisher,
    isbn,
    description,
    thumbnail,
  };
}

export async function searchBooks(query: string, startIndex: number = 0): Promise<Book[]> {
  try {
    const url = `${GOOGLE_BOOKS_API_URL}?q=${encodeURIComponent(query)}&maxResults=20&startIndex=${startIndex}`;

    const response = await fetch(url);

    if (!response.ok) {
      console.error('Google Books API error:', response.status);
      return [];
    }

    const data = await response.json();

    if (!data.items || data.items.length === 0) {
      return [];
    }

    return data.items.map((item: any) => normalizeBook(item));
  } catch (error) {
    console.error('Error fetching from Google Books API:', error);
    return [];
  }
}

export async function getBookById(volumeId: string): Promise<Book | null> {
  try {
    const url = `${GOOGLE_BOOKS_API_URL}/${volumeId}`;

    const response = await fetch(url);

    if (!response.ok) {
      console.error('Google Books API error:', response.status);
      return null;
    }

    const data = await response.json();

    return normalizeBook(data);
  } catch (error) {
    console.error('Error fetching book details:', error);
    return null;
  }
}
