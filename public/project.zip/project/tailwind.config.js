/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'primary': '#f9f506',
        'background-light': '#f8f8f5',
        'background-dark': '#23220f',
        'card-light': '#ffffff',
        'card-dark': '#2d2c1b',
        'text-main-light': '#181811',
        'text-main-dark': '#f8f8f5',
        'text-sub-light': '#8c8b5f',
        'text-sub-dark': '#abaa95',
      },
      fontFamily: {
        'display': ['Spline Sans', 'sans-serif'],
      },
      borderRadius: {
        DEFAULT: '1rem',
        'lg': '1.5rem',
        'xl': '2rem',
      },
    },
  },
  plugins: [],
};
